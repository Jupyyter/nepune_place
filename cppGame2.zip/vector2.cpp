#include "sdlLib.hpp"
vector2 add(vector2 vct0,vector2 vct1){
    return vector2(vct0.x+vct1.x,vct0.y+vct1.y);
}